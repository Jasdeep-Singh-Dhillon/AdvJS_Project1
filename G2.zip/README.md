# AdvJS_Project1
Group Project 1 for Advanced JavaScript

TODO: Edit, Add and Filter
